package com.kangbc.kbcapplication5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {
    public String TAG = "KBC";
    public double[] value;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getCpuUsageStatistic();
//        calculateCpu();

        value = calculateCpu();

        String st;
        st = String.format("User :%.3f ", value[0]);
//        tvKernel.setText(st);
        Log.e(TAG, "onCreate: "+ st);
        st = String.format("Nice :%.3f ", value[1]);
//        tvUser.setText(st);
        Log.e(TAG, "onCreate: "+ st);
        st = String.format("Kernel:%.3f ", value[2]);
//        tvWait.setText(st);
        Log.e(TAG, "onCreate: "+ st);
        st = String.format("Idle :%.3f ", value[3]);
//        tvIdle.setText(st);
        Log.e(TAG, "onCreate: "+ st);
    }

    /**
     *
     * @return integer Array with 4 elements: user, system, idle and other cpu
     *         usage in percentage.
     */
    private int[] getCpuUsageStatistic() {

        String tempString = executeTop();

        tempString = tempString.replaceAll(",", "");
        tempString = tempString.replaceAll("User", "");
        tempString = tempString.replaceAll("System", "");
        tempString = tempString.replaceAll("IOW", "");
        tempString = tempString.replaceAll("IRQ", "");
        tempString = tempString.replaceAll("%", "");
        for (int i = 0; i < 10; i++) {
            tempString = tempString.replaceAll("  ", " ");
        }
        tempString = tempString.trim();
        String[] myString = tempString.split(" ");
        int[] cpuUsageAsInt = new int[myString.length];
        for (int i = 0; i < myString.length; i++) {
            myString[i] = myString[i].trim();
            cpuUsageAsInt[i] = Integer.parseInt(myString[i]);
            Log.e(TAG, "getCpuUsageStatistic: " + cpuUsageAsInt[i]);
        }
        return cpuUsageAsInt;
    }

    private String executeTop() {
        java.lang.Process p = null;
        BufferedReader in = null;
        String returnString = null;
        try {
            p = Runtime.getRuntime().exec("top -n 1");
            in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            while (returnString == null || returnString.contentEquals("")) {
                returnString = in.readLine();
            }
        } catch (IOException e) {
            Log.e("executeTop", "error in getting first line of top");
            e.printStackTrace();
        } finally {
            try {
                in.close();
                p.destroy();
            } catch (IOException e) {
                Log.e("executeTop", "error in closing and destroying top process");
                e.printStackTrace();
            }
        }
        return returnString;
    }

    public void MatrixTime(int delayTime) {
        long saveTime = System.currentTimeMillis();
        long currTime = 0;

        while (currTime - saveTime < delayTime) {
            currTime = System.currentTimeMillis();
        }
    }

    public void getCpuStatFromFile(long[] value) {
        ProcessBuilder cmd;
        String tempStr = null;
        try {
            String[] args = { "/system/bin/cat", "/proc/stat" };
            cmd = new ProcessBuilder(args);
            java.lang.Process process = cmd.start();
            InputStream in = process.getInputStream();
            byte[] re = new byte[1024];
            in.read(re);
            tempStr = new String(re);
            StringTokenizer st = new StringTokenizer(tempStr, " ");
            String arrPrint[] = new String[st.countTokens()];

            int i = 0;
            for (int k = 0; st.hasMoreTokens(); k++) {
                arrPrint[k] = st.nextToken();
                if (k == 0)
                    continue;
                value[i] = Long.parseLong(arrPrint[k]);

                i++;
                if (k == 6)
                    break;
            }

            in.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public double[] calculateCpu() {
        long prev_cpu[] = new long[10];
        long cur_cpu[] = new long[10];
        long calc_cpu[] = new long[5];
        double value[] = new double[5];
        long total = 0;
        getCpuStatFromFile(prev_cpu);

        MatrixTime(1000);
        getCpuStatFromFile(cur_cpu);

        for (int k = 0; k < 5; k++) {
            calc_cpu[k] = cur_cpu[k] - prev_cpu[k];
            total += calc_cpu[k];
        }

        for (int k = 0; k < 5; k++) {
            value[k] = 100 * calc_cpu[k] / (double) total;
            Log.e(TAG, "calculateCpu: " + value[k]);
        }

        return value;

    }
}
