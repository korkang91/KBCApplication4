package com.kangbc.kbcapplication4.Data;

/**
 * Created by mac on 2017. 6. 23..
 */

public class Coord {
    public double lat;
    public double lon;

    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }
}
