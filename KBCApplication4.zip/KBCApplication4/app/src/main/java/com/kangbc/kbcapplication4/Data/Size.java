package com.kangbc.kbcapplication4.Data;

/**
 * Created by mac on 2017. 6. 27..
 */

public class Size {
    Integer width;
    Integer height;

    public Integer getHeight() {
        return height;
    }

    public Integer getWidth() {

        return width;
    }
}
