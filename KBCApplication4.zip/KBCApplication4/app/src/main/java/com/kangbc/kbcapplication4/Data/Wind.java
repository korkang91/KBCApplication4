package com.kangbc.kbcapplication4.Data;

/**
 * Created by mac on 2017. 6. 23..
 */

public class Wind {
    public Double speed;
    public Double deg;

    public Double getSpeed() {
        return speed;
    }

    public Double getDeg() {
        return deg;
    }
}
