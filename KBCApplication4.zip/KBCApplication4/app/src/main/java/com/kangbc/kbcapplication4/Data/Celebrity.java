package com.kangbc.kbcapplication4.Data;

/**
 * Created by mac on 2017. 6. 27..
 */

public class Celebrity {
    private String value;
    private double confidence;

    public String getValue() {
        return value;
    }

    public double getConfidence() {
        return confidence;
    }
}
