package com.kangbc.kbcapplication4;

import com.kangbc.kbcapplication4.Data.Faces;
import com.kangbc.kbcapplication4.Data.Info;

/**
 * Created by mac on 2017. 6. 26..
 */

public class NaverRepo2 {
    Info info;
    Faces[] faces;

    public Info getInfo() {
        return info;
    }

    public Faces[] getFaces() {
        return faces;
    }
}
