package com.kangbc.kbcapplication4;

import com.kangbc.kbcapplication4.Data.Faces;
import com.kangbc.kbcapplication4.Data.Info;

import java.util.List;

/**
 * Created by mac on 2017. 6. 26..
 */

public class NaverRepo {
    Info info;
    Faces[] faces;

    public Info getInfo() {
        return info;
    }

    public Faces[] getFaces() {
        return faces;
    }
}
