package com.kangbc.kbcapplication4.Data;

/**
 * Created by mac on 2017. 7. 7..
 */

public class Pose {
    public String value;
    public double confidence;

    public String getValue() {
        return value;
    }

    public double getConfidence() {
        return confidence;
    }
}
